import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Calendar, MapPin, Swords, Layers, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const TournamentOverview = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const infoCardRef = useRef<HTMLDivElement>(null);
  const textGroupRef = useRef<HTMLDivElement>(null);
  const thumbnailRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(
        infoCardRef.current,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        '.overview-h2',
        { x: '40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        '.overview-body',
        { y: '6vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.06
      );

      scrollTl.fromTo(
        '.overview-cta',
        { scale: 0.92, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        thumbnailRef.current,
        { y: '18vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.12
      );

      // SETTLE (30-70%): Static

      // EXIT (70-100%)
      scrollTl.fromTo(
        infoCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-45vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        '.overview-h2, .overview-body, .overview-cta',
        { x: 0, opacity: 1 },
        { x: '35vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        thumbnailRef.current,
        { y: 0, opacity: 1 },
        { y: '16vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        '.overview-bg',
        { scale: 1 },
        { scale: 1.05, ease: 'none' },
        0.7
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToTravel = () => {
    const element = document.querySelector('#travel');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const tournamentDetails = [
    { icon: Calendar, label: 'Date', value: 'April 11–12, 2026' },
    { icon: MapPin, label: 'Venue', value: 'J-Green Sakai City' },
    { icon: Swords, label: 'Format', value: 'Round-robin → Knockout' },
    { icon: Layers, label: 'Divisions', value: 'Open / Women\'s / U18 / U16' },
  ];

  return (
    <section
      ref={sectionRef}
      id="overview"
      className="section-pinned z-20"
    >
      {/* Background Image */}
      <div
        className="overview-bg absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: 'url(/pitch_midfield.jpg)' }}
      >
        <div className="absolute inset-0 bg-[#0B3D2E]/55" />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center px-6 lg:px-12 pt-20">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            {/* Left: Info Card */}
            <div
              ref={infoCardRef}
              className="card-white p-6 lg:p-10"
            >
              <h3
                className="text-2xl font-bold text-[#0B3D2E] mb-6"
                style={{ fontFamily: 'League Spartan, sans-serif' }}
              >
                Tournament Details
              </h3>

              <div className="space-y-5">
                {tournamentDetails.map((detail, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#CFFF2E]/20 flex items-center justify-center flex-shrink-0">
                      <detail.icon className="w-5 h-5 text-[#0B3D2E]" />
                    </div>
                    <div>
                      <div className="text-sm text-[#0B3D2E]/60 uppercase tracking-wider">
                        {detail.label}
                      </div>
                      <div className="text-[#0B3D2E] font-semibold">
                        {detail.value}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Text Content */}
            <div ref={textGroupRef} className="space-y-6">
              <h2
                className="overview-h2 text-4xl sm:text-5xl lg:text-6xl text-white font-black"
                style={{ fontFamily: 'League Spartan, sans-serif' }}
              >
                J-GREEN
                <br />
                <span className="text-[#CFFF2E]">SAKAI</span>
              </h2>

              <p className="overview-body text-white/80 text-lg leading-relaxed max-w-lg">
                A world-class rugby venue in Osaka. Two days of fast-paced
                international tag. Live updates, video highlights, and
                play-by-play coverage.
              </p>

              <button
                onClick={scrollToTravel}
                className="overview-cta btn-outline inline-flex items-center gap-2"
              >
                Get Travel Info
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Matchday Thumbnail */}
              <div
                ref={thumbnailRef}
                className="mt-8 card-white p-4 flex items-center gap-4 max-w-xs"
              >
                <div
                  className="w-16 h-16 rounded-xl bg-cover bg-center flex-shrink-0"
                  style={{ backgroundImage: 'url(/pitch_close.jpg)' }}
                />
                <div>
                  <div className="text-sm text-[#0B3D2E]/60">Matchday</div>
                  <div className="text-[#0B3D2E] font-bold">Day 1 & 2</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TournamentOverview;
